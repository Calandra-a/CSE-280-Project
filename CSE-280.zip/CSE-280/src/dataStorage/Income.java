package dataStorage;

import scenes.fiscal.PayPeriods;

/**
 * Created by User on 2/19/2017.
 */
public class Income {

    private PayPeriods.PayPeriod period;
    private String name;
    private double payAmount;

    public Income(PayPeriods.PayPeriod period, double payAmount) {
        this.period = period;
        this.payAmount = payAmount;
    }

    public Income(String name, double payAmount) {
        this.name = name;
        this.payAmount = payAmount;
    }
}
