package scenes.savings;

import controllers.BudgetMeController;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.util.StringConverter;
import scenes.fiscal.Income;
import scenes.fiscal.PayPeriods;
import javax.swing.text.DateFormatter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

/**
 * Created by Boba3d on 3/11/2017.
 */

public class Controller extends BudgetMeController{

    @FXML
    private TextField savingsName1;

    @FXML
    private TextField savingsAmount;

    @FXML
    private TextField percentField;

    @FXML
    private DatePicker datePicker;

    @FXML
    private ComboBox comboBox;

    //saving info into arrayLists
    ArrayList date = new ArrayList();
    ArrayList savingsName = new ArrayList();
    ArrayList amount = new ArrayList();



    @FXML
    private void savingsSubmit() {
        //store the date as type LocalDate and add them to the ArrayLists.
        LocalDate chosenDate = datePicker.getValue();

        savingsName.add(savingsName1.getText());
        amount.add(savingsAmount.getText());
        date.add(chosenDate);

        System.out.println("Date: " +date.get(0));
        System.out.println("Savings Name: " + savingsName.get(0));
        System.out.println("Amount: " + amount.get(0));

        comboBox.getItems().addAll(savingsName1.getText());
        //obj.getAmount();

        //System.out.println(obj);
    }


    @FXML
    private void percentIncome(){
        //Adjust percent for allotted income
        // need to get income as an object and modify it.
        if(percentField.getText() == null) {
            System.out.println("You didn't enter a percent!");
        }
        else{
        Double percent = Double.parseDouble(percentField.getText());
            if(percent >101 || percent <0){
                System.out.println("This percent is not between 1 and 100");

            }
        }




    }

}
