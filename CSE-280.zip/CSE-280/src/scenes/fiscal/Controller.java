package scenes.fiscal;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import controllers.BudgetMeController;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.util.ArrayList;
import dataStorage.Income;


/**
 * Created by Lauren on 2/18/2017.
 */
public class Controller extends BudgetMeController {

    @FXML
    private ComboBox<PayPeriods.PayPeriod> incomeBox1;
    @FXML
    private TextArea incomeDollarField1;
    @FXML
    private Button incomeSubmitButton;
    @FXML
    private Button otherSubmitButton;
    @FXML
    private TextField incomeField;
    @FXML
    private TextField incomeDollarField2;
    @FXML
    private Button expenseButton1;
    @FXML
    private Button expenseButton2;
    @FXML
    private TextField expenseField1;
    @FXML
    private TextField expenseField2;
    @FXML
    private TextField expenseDollarField1;
    @FXML
    private TextField expenseDollarField2;


    //Expense combobox 1
    @FXML
    private ComboBox<PayPeriods.PayPeriod> expenseBox1;
    @FXML
    private ObservableList<PayPeriods.PayPeriod> expenseBoxData1 = FXCollections.observableArrayList(PayPeriods.PayPeriod.values());
    //Expense combobox 2
    @FXML
    private ComboBox<PayPeriods.PayPeriod> expenseBox2;
    @FXML
    private ObservableList<PayPeriods.PayPeriod> expenseBoxData2 = FXCollections.observableArrayList(PayPeriods.PayPeriod.values());

    @FXML
    private ObservableList<PayPeriods.PayPeriod> incomeBoxData = FXCollections.observableArrayList(PayPeriods.PayPeriod.values());

    // Sets items in the dropdown
    @FXML
    private ComboBox comboBoxIncome;

    @FXML
    private ComboBox comboBoxExpense;

    @FXML
    private void initialize() {
        incomeBox1.setItems(incomeBoxData);
        expenseBox1.setItems(expenseBoxData1);
        expenseBox2.setItems(expenseBoxData1);
    }

    ArrayList incomePeriods = new ArrayList();
    ArrayList income = new ArrayList();
    ArrayList amount = new ArrayList();
    // Performs action on the first income submit button (pay period and the amount)
    @FXML
    private void handleIncomeButtonAction(ActionEvent event) {
        PayPeriods.PayPeriod period = incomeBox1.getSelectionModel().getSelectedItem();
        String income = incomeDollarField1.getText();

        System.out.println(period);
        System.out.println(income);

        Double d = Double.parseDouble(income);

        //Income incomeObject = new Income(period, d);
        Income theIncome = new Income(period, d);
    }


        //Performs action on the second income submit button (name and the amount)
    @FXML
    private void handleOtherButtonAction(ActionEvent event) {
        String otherIncome = incomeField.getText();
        String otherAmount = incomeDollarField2.getText();

        System.out.println(otherIncome);
        System.out.println(otherAmount);

        Double d = Double.parseDouble(otherAmount);

        comboBoxIncome.getItems().addAll(incomeField.getText() +" "+ incomeDollarField2.getText()  );

        Income incomeObject = new Income(otherIncome, d);


    }

    //stores values from both button handlers
    ArrayList payPeriods = new ArrayList();
    ArrayList expenseNames = new ArrayList();
    ArrayList expenses = new ArrayList();

    //String[] payPeriods = {};
    //String[] expenseNames = {null};//replace with arraylist?
    //double[] expenses = {0.00};
    @FXML
    private void expenseSubmitOneHandler() {
        //appends each value to the end of the array list
        payPeriods.add(expenseBox1.getSelectionModel().getSelectedItem());
        expenseNames.add(expenseField1.getText());
        expenses.add(expenseDollarField1.getText());
        System.out.println("payPeriod: " + payPeriods.get(0));
        System.out.println("expenseName :" + expenseNames.get(0));
        System.out.println("expense amount: " + expenses.get(0));
        System.out.println("payPeriod: " + payPeriods.get(0));
        System.out.println("expenseName :" + expenseNames.get(0));
        System.out.println("expense amount: " + expenses.get(0));
    }

    @FXML
    private void expenseSubmitTwoHandler() {
        payPeriods.add(expenseBox2.getSelectionModel().getSelectedItem());
        expenseNames.add(expenseField2.getText());
        expenses.add(expenseDollarField2.getText());

        comboBoxExpense.getItems().addAll(expenseBox2.getSelectionModel().getSelectedItem()+ " " + expenseField2.getText() + " "+expenseDollarField2.getText()  );
    }


    public ArrayList getInfo(int index)
    {
        ArrayList returns = new ArrayList();
        returns.add(payPeriods.get(index));
        returns.add(expenseNames.get(index));
        returns.add(expenses.get(index));
        return returns;
    }

    public void toSavings() throws Exception
            //To Savings Goal scene!
    {
       controllerManager.savingsScene();

    }


}









