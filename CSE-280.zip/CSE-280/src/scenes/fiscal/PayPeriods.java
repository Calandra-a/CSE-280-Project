package scenes.fiscal;

/**
 * Created by Lauren on 2/19/2017.
 */

// This is for populating the dropdown menu for pay periods
public class PayPeriods {
    public enum PayPeriod {
        MONTHLY("Monthly"),
        BIWEEKLY("Biweekly"),
        WEEKLY("Weekly"),
        DAILY("Daily");

        private String label;

        PayPeriod(String label) {
            this.label = label;
        }

        public String toString() {
            return label;
        }
    }
}
