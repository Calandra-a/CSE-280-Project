package scenes.fiscal;

/**
 * Created by Boba3d on 3/15/2017.
 */
public class Income {

    private PayPeriods.PayPeriod timePeriod;
    private double theAmount;


    public Income(PayPeriods.PayPeriod time , double amount){
        this.timePeriod = time;
        this.theAmount = amount;
    }
    public PayPeriods.PayPeriod getPayPeriod(){
        return timePeriod;
    }
    public double getAmount(){
        return theAmount;
    }

}
